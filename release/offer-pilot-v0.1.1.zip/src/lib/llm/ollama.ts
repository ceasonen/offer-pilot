export const OLLAMA_CONFIG = {
  baseURL: 'http://localhost:11434/v1',
  defaultModel: 'llama3.1',
};
