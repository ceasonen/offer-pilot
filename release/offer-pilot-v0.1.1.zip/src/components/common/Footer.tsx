export function Footer() {
  return (
    <footer className="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
      OfferPilot · AI 大厂面试官 · MIT License
    </footer>
  );
}
