import { InterviewRoom } from '@/components/interview/InterviewRoom';

export default function RoomPage() {
  return <InterviewRoom />;
}
