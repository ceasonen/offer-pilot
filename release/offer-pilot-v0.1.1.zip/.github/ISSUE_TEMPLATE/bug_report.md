---
name: Bug report
about: Report a reproducible bug
---

## Description

## Steps to reproduce

1.
2.
3.

## Expected behavior

## Environment

- OS:
- Browser:
- Node.js:
