# Question Format

Example JSON item:

```json
{
  "id": "react-001",
  "question": "React 里 key 的作用是什么？",
  "difficulty": 2,
  "tags": ["react", "diff"],
  "idealPoints": [
    "帮助识别节点稳定性",
    "减少错误复用",
    "影响重排性能"
  ]
}
```
