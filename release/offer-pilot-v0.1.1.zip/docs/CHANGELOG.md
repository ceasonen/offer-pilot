# Changelog

## 0.1.1

- Fix DeepSeek chat integration for AI SDK v6 (`useChat`/message flow).
- Add explicit API key and request error feedback in interview room.
- Improve loading state handling to avoid "stuck with no response" behavior.

## 0.1.0

- Initial MVP scaffold
- Interview room + report flow
- Multi-provider LLM adapter
