# Prompt Design

Prompt modules:

- `system.ts`: global interviewer rules
- `interviewer.ts`: interview orchestration prompt
- `evaluator.ts`: single-answer scoring prompt
- `reporter.ts`: final report prompt
- `companies/*.ts`: company persona profiles
