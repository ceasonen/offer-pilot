# Contributing

1. Fork and create a feature branch.
2. Keep changes focused and add docs/tests when needed.
3. Submit PR with clear summary and screenshots for UI changes.
