export const OPENAI_CONFIG = {
  baseURL: 'https://api.openai.com/v1',
  defaultModel: 'gpt-4o-mini',
};
