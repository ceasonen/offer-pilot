export const DEEPSEEK_CONFIG = {
  baseURL: 'https://api.deepseek.com',
  defaultModel: 'deepseek-chat',
};
