---
name: Feature request
about: Suggest an idea for OfferPilot
---

## Problem

## Proposed solution

## Alternatives considered
